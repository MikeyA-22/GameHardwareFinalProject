using UnityEngine;
using System;
using System.Net;
using System.Text;
using System.Net.Sockets;

public class Client : MonoBehaviour
{
    public GameObject myCube;
    private static byte[] buffer = new byte[1024];
    private static IPEndPoint remoteEP;
    private static Socket client;
    [SerializeField]private float sendRate = 0.1f;
    private float nextSendTime = 0f;
    private Vector3 lastPosition;

    public static void StartClient()
    {
        try
        {
            IPAddress ip = IPAddress.Parse("127.0.0.1");
            remoteEP = new IPEndPoint(ip, 1111);

            client = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
            client.Blocking = true;
        }
        catch (Exception e)
        {
            Debug.Log("Exception: " + e);
        }
    }

    private void Start()
    {
        myCube = GameObject.Find("Cube");
        StartClient();
    }

    private void Update()
    {
        
        if (Input.GetKey(KeyCode.Minus))
        {
            sendRate -= 0.01f; // Lower bound of 0.01scnds
            Debug.Log("Send rate decreased to: " + sendRate);
        }
        else if (Input.GetKey(KeyCode.Equals))
        {
            sendRate += 0.01f;
            Debug.Log("Send rate increased to: " + sendRate);
        }

        // Send only if the cube has moved and the interval has passed
        if (Time.time >= nextSendTime && myCube.transform.position != lastPosition)
        {
            nextSendTime = Time.time + sendRate;
            lastPosition = myCube.transform.position;

            string positionData = $"{lastPosition.x},{lastPosition.y},{lastPosition.z}";
            buffer = Encoding.ASCII.GetBytes(positionData);

            client.SendTo(buffer, remoteEP);
            Debug.Log("Sent: " + positionData);
        }
    }
}