using UnityEngine;
using System;
using System.Net;
using System.Text;
using System.Net.Sockets;

public class Server : MonoBehaviour
{
    public GameObject serverCube;
    private byte[] buffer = new byte[1024];
    private Socket serverSocket;
    private EndPoint remoteClient;

    private Vector3 receivedPosition;
    private bool isNewDataReceived = false;

    public void StartServer()
    {
        try
        {
            IPAddress ip = IPAddress.Parse("127.0.0.1");
            IPEndPoint localEP = new IPEndPoint(ip, 1111);

            serverSocket = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
            serverSocket.Bind(localEP);

            Debug.Log("Server started on " + localEP);

            IPEndPoint client = new IPEndPoint(IPAddress.Any, 0);
            remoteClient = (EndPoint)client;

            serverSocket.BeginReceiveFrom(buffer, 0, buffer.Length, SocketFlags.None, ref remoteClient, new AsyncCallback(ReceiveCallback), null);
        }
        catch (Exception e)
        {
            Debug.LogError("Exception: " + e);
        }
    }

    private void ReceiveCallback(IAsyncResult ar)
    {
        try
        {
            int received = serverSocket.EndReceiveFrom(ar, ref remoteClient);
            string data = Encoding.UTF8.GetString(buffer, 0, received);
            Debug.Log("Received: " + data); // Debug incoming data

            
            data = data.Trim();

            // Split the received data into x, y, z
            string[] positionData = data.Split(',');
            if (positionData.Length == 3)
            {
                if (float.TryParse(positionData[0], out float x) &&
                    float.TryParse(positionData[1], out float y) &&
                    float.TryParse(positionData[2], out float z))
                {
                    receivedPosition = new Vector3(x, y, z);
                    isNewDataReceived = true;
                }
                else
                {
                    Debug.LogError("Error parsing received position data.");
                }
            }
            else
            {
                Debug.LogError("Invalid data format received: " + data);
            }

            // Continue listening for new data
            serverSocket.BeginReceiveFrom(buffer, 0, buffer.Length, SocketFlags.None, ref remoteClient, new AsyncCallback(ReceiveCallback), null);
        }
        catch (Exception e)
        {
            Debug.LogError("ReceiveCallback Exception: " + e);
        }
    }

    private void Start()
    {
        StartServer();
        //serverCube = GameObject.Find("ServerCube");
    }

    private void Update()
    {
        if (isNewDataReceived)
        {
            serverCube.transform.position = receivedPosition;
            isNewDataReceived = false;
        }
    }
}
